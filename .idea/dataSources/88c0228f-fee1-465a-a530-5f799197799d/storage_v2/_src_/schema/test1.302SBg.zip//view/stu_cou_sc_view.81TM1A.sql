create definer = root@localhost view stu_cou_sc_view as
select `s`.`name` AS `student_name`, `s`.`no` AS `student_number`, `c`.`name` AS `course_name`
from `test1`.`student` `s`
         join `test1`.`course` `c`
         join `test1`.`student_course` `sc`
where ((`s`.`id` = `sc`.`studentid`) and (`c`.`id` = `sc`.`courseid`));

-- comment on column stu_cou_sc_view.student_name not supported: 姓名

-- comment on column stu_cou_sc_view.student_number not supported: 学号

-- comment on column stu_cou_sc_view.course_name not supported: 课程名称

